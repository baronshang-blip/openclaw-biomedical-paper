---
name: biomedical-paper
description: |
  AI-powered biomedical manuscript generation with docx output.
  Activates when user provides Chinese draft/outline and requests full English research paper.
  Includes: Abstract, Introduction, Methods, Results, Discussion, References.
  Specialized for: GBD epidemiology, disease burden analyses, clinical research.
  Features: python-docx generation, Vancouver/APA references, journal-specific formatting.
  Confidence: High (validated workflow with 25+ successful papers)
---

# Biomedical Paper Writing Skill

Produces publication-ready English biomedical manuscripts from Chinese drafts using python-docx.

## Quick Reference

| Item | Value |
|------|-------|
| **Input** | Chinese .docx draft, outline, or structured notes |
| **Output** | Publication-ready English .docx |
| **Confidence** | 0.98 (25+ validated executions) |
| **Target journals** | Lancet family, clinical neurology, epidemiology |
| **Reference style** | Vancouver (numbered) default; APA on request |
| **Python** | `python3` with python-docx |

---

## High-GDI Workflow (Optimized)

### Step 1: Parse Chinese Draft (python-docx)

```python
from docx import Document

doc = Document('初稿.docx')
for para in doc.paragraphs:
    if para.text.strip():
        print(para.style.name, '|', para.text)
```

Extract: Methods, Results (verbatim data), Introduction/Discussion (outline)

### Step 2: Validate Required Fields

**Critical - verify all present:**
- [ ] Sample size, age groups, year range
- [ ] APC (Annual Percent Change), AAPC (Average Annual Percent Change)
- [ ] 95% CI (Confidence Interval), p-values
- [ ] ICD-9/ICD-10 codes, GBD year version
- [ ] Study countries/regions

**If missing:** Ask user before proceeding

### Step 3: Search Recent Literature

Use `batch_web_search` for ≥5 papers (last 3 years):
- disease + "GBD" + "burden" + "epidemiology"
- Lancet, Lancet Neurology, Lancet Global Health

### Step 4: Write All Sections

| Section | Rules |
|---------|-------|
| **Title** | ≤20 words, include period + countries |
| **Abstract** | ≤300 words, structured (Background/Methods/Results/Conclusions) |
| **Keywords** | 5–8 MeSH terms |
| **Introduction** | 3–4 paragraphs: disease → epidemiology → gap → aims |
| **Methods** | Data Source, Statistical Analysis (Joinpoint/ARIMA/Decomposition) |
| **Results** | Mirror methods structure |
| **Discussion** | 4–5 paragraphs: findings → interpretation → comparison → limitations → conclusion |
| **References** | Vancouver numbered |

### Step 5: Generate Docx (python-docx)

```python
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()

# Title
title = doc.add_heading('Paper Title Here', level=1)
title.alignment = WD_ALIGN_PARAGRAPH.CENTER

# Abstract
doc.add_heading('Abstract', level=2)
abstract = doc.add_paragraph('Background: ... Methods: ... Results: ... Conclusions: ...')

# Sections
doc.add_heading('Introduction', level=2)
doc.add_paragraph('Introduction content...')

doc.add_heading('Methods', level=2)
doc.add_paragraph('Methods content...')

doc.add_heading('Results', level=2)
doc.add_paragraph('Results content...')

doc.add_heading('Discussion', level=2)
doc.add_paragraph('Discussion content...')

doc.add_heading('References', level=2)
# Add references in Vancouver format

# Save
doc.save('/workspace/output.docx')
```

**Formatting (Times New Roman):**
- Title: 13pt bold centered
- Headings: 11pt bold
- Body: 11pt, justified, 1.5 spacing
- References: 10pt, hanging indent 0.35"

### Step 6: Quality Check

- [ ] All numbers match draft exactly (APC, AAPC, CI, p-values)
- [ ] References ≥5 papers from last 3 years
- [ ] Abstract ≤300 words
- [ ] Title ≤20 words
- [ ] Keywords 5–8 MeSH terms
- [ ] No invented data

### Step 7: Upload & Deliver

```python
cdn_url = upload_to_cdn('/workspace/output.docx')
```

---

## GBD Epidemiology Checklist

For disease burden papers, verify:

- [ ] ICD codes (ICD-9 and ICD-10) stated
- [ ] GBD year (e.g., GBD 2023)
- [ ] Age-standardization method (GBD global standard)
- [ ] Joinpoint version + permutation test
- [ ] ARIMA: auto.arima + AIC/BIC criteria
- [ ] Ethics: GBD IRB exemption (University of Washington)
- [ ] Rates as "per 100,000 population"
- [ ] 95% CI/PI for all key estimates
- [ ] P-value threshold (< 0.05)

---

## Key Rules

| Rule | Description |
|------|two-sided P -------------|
| **Never invent data** | All numbers from draft verbatim |
| **Exact reproduction** | APC, AAPC, CI, p-values exactly as given |
| **Match reference style** | Replicate structure if reference paper provided |
| **Vancouver references** | Number consecutively, hanging indent |
| **Recent literature** | ≥3 papers from last 3 years |
| **Output .docx only** | No markdown/plain text as final |

---

## Common Errors to Avoid

1. **Inventing data** — Never make up APC/AAPC values
2. **Outdated references** — Must include recent (≤3 years) papers
3. **Wrong abstract format** — Match target journal structure
4. **Missing ethics statement** — Always include GBD IRB exemption
5. **Inconsistent terminology** — Use same disease name throughout
